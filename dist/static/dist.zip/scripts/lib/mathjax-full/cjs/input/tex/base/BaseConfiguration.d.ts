import { Configuration } from '../Configuration.js';
import TexParser from '../TexParser.js';
import { AbstractTags } from '../Tags.js';
import './BaseMappings.js';
export declare function Other(parser: TexParser, char: string): void;
export declare class BaseTags extends AbstractTags {
}
export declare const BaseConfiguration: Configuration;
