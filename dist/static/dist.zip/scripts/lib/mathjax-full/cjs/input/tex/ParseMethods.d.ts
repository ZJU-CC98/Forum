import { Token } from './Token.js';
import TexParser from './TexParser.js';
declare namespace ParseMethods {
    function variable(parser: TexParser, c: string): void;
    function digit(parser: TexParser, c: string): void;
    function controlSequence(parser: TexParser, _c: string): void;
    function lcGreek(parser: TexParser, mchar: Token): void;
    function ucGreek(parser: TexParser, mchar: Token): void;
    function mathchar0mi(parser: TexParser, mchar: Token): void;
    function mathchar0mo(parser: TexParser, mchar: Token): void;
    function mathchar7(parser: TexParser, mchar: Token): void;
    function delimiter(parser: TexParser, delim: Token): void;
    function environment(parser: TexParser, env: string, func: Function, args: any[]): void;
}
export default ParseMethods;
