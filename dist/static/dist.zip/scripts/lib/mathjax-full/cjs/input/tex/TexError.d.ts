export default class TexError {
    id: string;
    private static pattern;
    message: string;
    private static processString;
    constructor(id: string, message: string, ...rest: string[]);
}
