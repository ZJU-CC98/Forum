import { Configuration } from '../Configuration.js';
import './TextcompMappings.js';
export declare const TextcompConfiguration: Configuration;
