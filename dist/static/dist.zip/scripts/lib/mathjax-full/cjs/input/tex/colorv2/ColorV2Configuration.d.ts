import { Configuration } from '../Configuration.js';
import { ParseMethod } from '../Types.js';
export declare const ColorV2Methods: Record<string, ParseMethod>;
export declare const ColorConfiguration: Configuration;
