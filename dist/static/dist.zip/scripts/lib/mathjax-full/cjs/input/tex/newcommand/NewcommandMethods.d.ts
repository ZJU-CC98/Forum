import { ParseMethod } from '../Types.js';
declare let NewcommandMethods: Record<string, ParseMethod>;
export default NewcommandMethods;
