import { MultlineItem } from '../ams/AmsItems.js';
export declare class MultlinedItem extends MultlineItem {
    get kind(): string;
    EndTable(): void;
}
