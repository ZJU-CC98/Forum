import { ParseMethod } from '../Types.js';
export declare const AmsMethods: Record<string, ParseMethod>;
export declare const NEW_OPS = "ams-declare-ops";
