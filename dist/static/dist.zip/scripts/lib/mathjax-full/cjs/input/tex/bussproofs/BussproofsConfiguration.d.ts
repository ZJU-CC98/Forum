import { Configuration } from '../Configuration.js';
import './BussproofsMappings.js';
export declare const BussproofsConfiguration: Configuration;
