import { Configuration } from '../Configuration.js';
export declare const HtmlConfiguration: Configuration;
