import { ParseMethod } from '../Types.js';
declare let HtmlMethods: Record<string, ParseMethod>;
export default HtmlMethods;
