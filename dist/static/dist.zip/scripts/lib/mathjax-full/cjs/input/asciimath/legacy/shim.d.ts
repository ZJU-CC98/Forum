export const AsciiMath: any;
