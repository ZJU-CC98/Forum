export declare function sortLength(a: string, b: string): number;
export declare function quotePattern(text: string): string;
export declare function unicodeChars(text: string): number[];
export declare function unicodeString(data: number[]): string;
export declare function isPercent(x: string): boolean;
export declare function split(x: string): string[];
export declare function replaceUnicode(text: string): string;
