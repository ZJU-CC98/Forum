export declare function asyncLoad(name: string): Promise<void>;
