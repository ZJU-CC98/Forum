export declare function sum(A: number[]): number;
export declare function max(A: number[]): number;
