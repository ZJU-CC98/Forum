import { ChtmlWrapperClass } from './Wrapper.js';
export declare const ChtmlWrappers: {
    [kind: string]: ChtmlWrapperClass<any, any, any>;
};
