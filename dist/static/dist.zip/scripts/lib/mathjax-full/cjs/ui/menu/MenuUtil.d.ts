export declare const isMac: boolean;
export declare function copyToClipboard(text: string): void;
