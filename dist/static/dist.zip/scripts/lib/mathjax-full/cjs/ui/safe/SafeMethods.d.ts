import { FilterFunction } from './safe.js';
export declare const SafeMethods: {
    [name: string]: FilterFunction<any, any, any>;
};
