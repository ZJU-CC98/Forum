import { ChtmlFontData } from './FontData.js';
export declare const fontName: string;
export declare const DefaultFont: typeof ChtmlFontData;
