export declare const ZeroFontDataUrl: string;
