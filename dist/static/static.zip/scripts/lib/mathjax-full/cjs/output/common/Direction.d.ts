export declare const enum DIRECTION {
    None = 0,
    Vertical = 1,
    Horizontal = 2
}
export declare const V = DIRECTION.Vertical;
export declare const H = DIRECTION.Horizontal;
