import { SvgWrapperClass } from './Wrapper.js';
export declare const SvgWrappers: {
    [kind: string]: SvgWrapperClass<any, any, any>;
};
