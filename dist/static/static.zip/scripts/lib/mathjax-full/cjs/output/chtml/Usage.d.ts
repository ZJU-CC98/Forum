export declare class Usage<T> {
    protected used: Set<string>;
    protected needsUpdate: T[];
    add(item: T): void;
    has(item: T): boolean;
    clear(): void;
    update(): T[];
}
