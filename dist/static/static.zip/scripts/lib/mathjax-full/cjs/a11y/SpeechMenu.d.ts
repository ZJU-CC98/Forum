import { MJContextMenu } from '../ui/menu/MJContextMenu.js';
import { SubMenu, Submenu } from '../ui/menu/mj-context-menu.js';
export declare function clearspeakMenu(menu: MJContextMenu, sub: Submenu): any;
export declare function localeMenu(menu: MJContextMenu, sub: Submenu): SubMenu;
