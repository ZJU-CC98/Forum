import { AbstractMathList } from '../../core/MathList.js';
export declare class HTMLMathList<N, T, D> extends AbstractMathList<N, T, D> {
}
