import { HTMLHandler } from './html/HTMLHandler.js';
import { DOMAdaptor } from '../core/DOMAdaptor.js';
export declare function RegisterHTMLHandler<N, T, D>(adaptor: DOMAdaptor<N, T, D>): HTMLHandler<N, T, D>;
