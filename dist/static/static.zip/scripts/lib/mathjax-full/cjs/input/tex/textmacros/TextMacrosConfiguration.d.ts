import { Configuration } from '../Configuration.js';
import './TextMacrosMappings.js';
export declare const TextBaseConfiguration: Configuration;
export declare const TextMacrosConfiguration: Configuration;
