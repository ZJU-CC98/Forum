import { ParseMethod } from '../Types.js';
declare let BraketMethods: Record<string, ParseMethod>;
export default BraketMethods;
