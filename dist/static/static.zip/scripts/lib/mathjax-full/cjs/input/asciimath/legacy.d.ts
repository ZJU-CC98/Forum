export declare const LegacyAsciiMath: {
    Compile: (am: any, display: boolean) => any;
    Translate: (am: any, display: boolean) => any;
};
