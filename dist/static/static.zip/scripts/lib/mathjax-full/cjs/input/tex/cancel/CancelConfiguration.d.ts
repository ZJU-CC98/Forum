import { Configuration } from '../Configuration.js';
import { ParseMethod } from '../Types.js';
export declare let CancelMethods: Record<string, ParseMethod>;
export declare const CancelConfiguration: Configuration;
