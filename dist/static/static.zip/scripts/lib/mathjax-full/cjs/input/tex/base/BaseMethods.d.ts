import { ParseMethod } from '../Types.js';
declare let BaseMethods: Record<string, ParseMethod>;
export declare function splitAlignArray(align: string, n?: number): string;
export default BaseMethods;
