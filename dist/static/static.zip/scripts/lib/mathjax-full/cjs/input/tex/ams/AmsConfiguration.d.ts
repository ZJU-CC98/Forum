import { Configuration } from '../Configuration.js';
import { AbstractTags } from '../Tags.js';
import './AmsMappings.js';
export declare class AmsTags extends AbstractTags {
}
export declare const AmsConfiguration: Configuration;
