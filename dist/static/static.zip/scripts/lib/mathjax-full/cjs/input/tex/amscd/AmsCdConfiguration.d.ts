import { Configuration } from '../Configuration.js';
import './AmsCdMappings.js';
export declare const AmsCdConfiguration: Configuration;
