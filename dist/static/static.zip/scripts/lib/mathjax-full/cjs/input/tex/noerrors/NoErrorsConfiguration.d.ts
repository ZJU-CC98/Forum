import { Configuration } from '../Configuration.js';
export declare const NoErrorsConfiguration: Configuration;
