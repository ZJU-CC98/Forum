import { Configuration } from '../Configuration.js';
import './BraketMappings.js';
export declare const BraketConfiguration: Configuration;
