import { ParseMethod } from '../Types.js';
declare let AmsCdMethods: Record<string, ParseMethod>;
export default AmsCdMethods;
