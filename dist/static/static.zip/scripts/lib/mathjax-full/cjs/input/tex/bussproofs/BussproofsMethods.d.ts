import { ParseMethod } from '../Types.js';
declare let BussproofsMethods: Record<string, ParseMethod>;
export default BussproofsMethods;
