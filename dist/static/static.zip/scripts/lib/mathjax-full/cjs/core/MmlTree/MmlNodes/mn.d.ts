import { PropertyList } from '../../Tree/Node.js';
import { AbstractMmlTokenNode } from '../MmlNode.js';
export declare class MmlMn extends AbstractMmlTokenNode {
    static defaults: PropertyList;
    protected texclass: number;
    get kind(): string;
}
