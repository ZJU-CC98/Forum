import { PropertyList } from '../../Tree/Node.js';
import { AbstractMmlBaseNode, MmlNode } from '../MmlNode.js';
export declare class MmlMtd extends AbstractMmlBaseNode {
    static defaults: PropertyList;
    get kind(): string;
    get arity(): number;
    get linebreakContainer(): boolean;
    get linebreakAlign(): string;
    protected verifyChildren(options: PropertyList): void;
    setTeXclass(prev: MmlNode): this;
}
