import { PropertyList } from '../../Tree/Node.js';
import { MmlNode, AbstractMmlNode } from '../MmlNode.js';
export declare class MmlMenclose extends AbstractMmlNode {
    static defaults: PropertyList;
    protected texclass: number;
    get kind(): string;
    get arity(): number;
    get linebreakContainer(): boolean;
    setTeXclass(prev: MmlNode): MmlNode;
}
