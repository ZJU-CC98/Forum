export declare const VERSION = "4.0.0-beta.4";
