export declare function mjxRoot(): string;
