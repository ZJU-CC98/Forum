export declare function setBaseURL(URL: string): void;
