import { PrioritizedList, PrioritizedListItem } from './PrioritizedList.js';
export interface FunctionListItem extends PrioritizedListItem<Function> {
}
export declare class FunctionList extends PrioritizedList<Function> {
    execute(...data: any[]): boolean;
    asyncExecute(...data: any[]): Promise<void>;
}
