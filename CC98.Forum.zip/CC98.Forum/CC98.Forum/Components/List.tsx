﻿import * as React from 'react';
import { HotTopic } from "../Props/AppProps"
import * as State from "../States/AppState"
import * as Props from "../Props/AppProps"
import * as Module from "../module"
import { match } from "react-router";
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom';
import { MessageMatch } from '../Match/Match'


export class RouteComponent<TProps, TState, TMatch> extends React.Component<TProps, TState> {
    match: match<TMatch>;
    constructor(props, context) {
        super(props, context);
        this.match = props.match;
    }
}

export class List extends RouteComponent<{}, {}, {}>  {
    render() {
        return <Router>
            <div id="listRoot">
                <ListHead />
                <ListNotice />
                <Route component={ListButtonAndPager} />
                <ListTag />
                <Route path="/list/:page" component={ListContent} />
            </div>
        </Router>;
    }
}
export class ListHead extends RouteComponent<{}, State.ListHeadState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            imgUrl: "/images/ListImg.jpg",
            listName: "学术信息",
            todayTopics: 210,
            totalTopics: 12000,
            adsUrl: "/images/ads.jpg",
            listManager: "Dearkano",
            todayPosts: 90,
        }
    }
    render() {
        return <div className="column" style={{ width: "1140px", }}>
            <div className="row" style={{ flexDirection: "row", justifyContent: "space-between", width: "1140px" }}>
                <div style={{ flexgrow: "1", flexDirection: "row", display: "flex" }}>
                    <div id="ListImg" ><img src={this.state.imgUrl}></img></div>
                    <div className="column" style={{ marginTop: "20px", marginLeft: "10px" }}>
                        <div style={{ marginTop: "10px" }}><span>今日帖数</span><span>{this.state.todayPosts}</span></div>
                        <div style={{ marginTop: "10px" }}><span>今日主题</span><span>{this.state.todayTopics}</span></div>
                        <div style={{ marginTop: "10px" }}><span>总主题</span><span>{this.state.totalTopics}</span></div>
                    </div>
                </div>
                <div className="column" style={{ flexgrow: "0" }}>
                    <div id="like"><button style={{ border: "none", color: "#F5FAFC" }}>✰</button>  收藏版面</div>
                    <div ><img src={this.state.adsUrl} style={{ width: "250px", height: "60px" }}></img></div>
                </div>
            </div>
            <div className="row" style={{ marginTop: "5px" }}>
                <span>版主 : </span><span style={{ marginLeft: "5px" }}>{this.state.listManager}</span>
            </div>
        </div>;
    }
}
export class ListNotice extends RouteComponent<{}, State.ListNoticeState, {}> {
    constructor(props, context) {
        super(props, context);
        this.state = {
            notice: "1. 请大家首先阅读心灵之约版规再发帖，如有违规不接受pm卖萌求情；2. 诚征新版主，请去论坛事务版搜之前的版面负责人申请帖并遵循格式发帖，如有不明可以站短站务组组长咨询。3. 不要留联系方式！不要留联系方式！不要留联系方式！重要的事说三遍！，留任何联系方式tp1000天。 4. 更新了版规，增加了tp规则：成功诱导对方留联系方式的，tp1000天；修订了锁沉规则：有意义言之有物、希望继续讨论的长篇读后感将给予保留。5. 请理性讨论，不要人身攻击。违者tp1天起，累犯或严重的，上不封顶。",
        }
    }
    render() {
        return <div className="notice" style={{ marginTop: "10px" }}>
            <div id="noticeName">
                <span style={{ marginLeft: "15px", marginTop: "7px", color: "#FFFFFF" }}>本版公告</span>

            </div>
            <span style={{ marginLeft: "15px", marginTop: "15px", marginRight: "15px" }}>{this.state.notice}</span>
        </div>
    }
}
export class ListButtonAndPager extends RouteComponent<{}, State.ListPagerState, MessageMatch> {
    constructor(props, context) {
        super(props, context);
        this.state = {
            Pager: [],
            curPage: 1
        }
    }
    componentDidMount() {
        var curPage = this.match.params.page;
        console.log("cur=" + curPage);
        var pager = Module.getPager(curPage);
        if (curPage == undefined) {
            curPage = 1;
        }
        this.setState({
            Pager: pager,
            curPage: curPage
        });
    }
    render() {
        let pager = [];
        pager = this.state.Pager.map(Module.pageNumber);
        var lastPage = this.state.curPage - 1;
        var nextPage = this.state.curPage + 1;
        var lastPageUrl = "/list/page=" + lastPage;
        var nextPageUrl = "/list/page=" + nextPage;
        return <div className="row" style={{ width: "1140px", height: "50px", marginTop: "15px", justifyContent: "space-between", borderBottom: " #EAEAEA solid thin dashed", alignItems: "flex-end" }}>
            <div><button className="postTopic">发主题</button>
                <button className="postVote">发投票</button></div>
            <div id="pager" >
                <Link id="lastPage" className="pager" to={lastPageUrl} >&lt;</Link>
                <div className="row">{pager}</div>
                <Link id="nextPage" className="pager" to={nextPageUrl}>></Link>
            </div>
        </div>;
    }
}

export class ListTag extends RouteComponent<{}, State.ListTagState, {}> {
    constructor(props, context) {
        super(props, context);
        this.state = {
            tags: Array(["ow", ["lol", ["dota", ["csgo"]]]]),

        }
    }
    render() {
        return <div style={{ display: "flex", flexDirection: "row", justifyContent: "flex-start", width: "1140px", borderTop: "dashed #EAEAEA solid thin", marginTop: "25px", marginBottom: "25px" }}>
            <div className="row">  <button id="tagButton">全部</button>
                <button className="chooseTag">dota <span className="tagNumber">1234</span></button>
                <button className="chooseTag">csgo <span className="tagNumber">5687</span ></button></div>
        </div >;
    }
}

export class ListContent extends RouteComponent<Props.ListPagerProps, State.ListContentState, MessageMatch> {
    constructor(props, context) {
        super(props, context);

        this.state = {
            items: [],
            curPage: 1
        }
    }
    async componentDidMount() {
        var curPage = this.props.match.params.page;
        if (curPage == undefined) {
            curPage = 1;
        }
        var i = await Module.getBoardTopic(curPage);
        console.log(i);
        this.setState({
            items: i,
            curPage: curPage
        });
    }
    async componentDidUpdate() {
        console.log("didUpdate");
        console.log(this.state.items.map(Module.convertHotTopic));
    }


    componentWillUpdate(nextProps, nextState) {
        console.log("willUpdate");
        console.log(this.state.items);
        console.log(nextState.items);

    }
    async componentWillReceiveProps(nextProps) {
        var curPage = nextProps.match.params.page;
        if (curPage == undefined) {
            curPage = 1;
        }
        var i = await Module.getBoardTopic(curPage);
        console.log(i);
        this.setState({
            items: i
        });
    }
    render() {
        var items = this.state.items.map(Module.convertHotTopic);
        console.log("final");
        console.log(items);
        return <div className="listContent ">
            <div className="row" style={{ justifyContent: "space-between", }}>
                <div className="row" style={{ height: "40px" }}>
                    <button className="listContentTag">全部</button>
                    <button className="listContentTag">精华</button>
                    <button className="listContentTag">最热</button>
                </div>
                <div className="row" style={{ height: "40px", alignItems: "center" }}>
                    <div style={{ marginRight: "152px", marginLeft: "15px" }}><span>作者</span></div>
                    <div style={{ marginRight: "85px", marginLeft: "15px" }}><span>最后发表</span></div>
                </div>
            </div>
            <div>
                <TopicContentSet items={items} />
            </div>
        </div>;

    }
}
export class TopicContentSet extends RouteComponent<Props.topicSet, {}, {}>{
    render() {
        return <div>{this.props.items}</div>;
    }
}
export class TopicTitleAndContent extends RouteComponent<HotTopic, State.TopicTitleAndContentState, {}> {
    constructor(props, context) {
        super(props, context);
        this.state = {
            title: this.props.title,
            authorName: this.props.authorName,
            likeNumber: 123,
            unlikeNumber: 11,
            commentNumber: 214,
            lastReply: "Dearkano 2017-2-2",
        }
    }
    render() {
        return <div id="changeColor">
            <div className="row topicInList" >
                <div style={{ marginLeft: "20px", }}> <span >{this.state.title}</span></div>
                <div className="row">
                    <div style={{ marginRight: "10px", marginLeft: "15px", width: "80px" }}> <span >{this.state.authorName}</span></div>
                    <div className="row" style={{ flexDirection: "row", alignItems: "flex-end" }}>
                        <div id="liked"><img src={this.props.likeImgUrl}></img><span className="timeProp tagSize">{this.state.likeNumber}</span></div>
                        <div id="unliked"><img src={this.props.unlikeImgUrl}></img><span className="timeProp tagSize">{this.state.unlikeNumber}</span></div>
                        <div id="commentsAmount"><img src={this.props.commentImgUrl}></img><span className="timeProp tagSize">{this.state.commentNumber}</span></div>
                    </div>
                    <div id="lastReply"><span >{this.state.lastReply}</span></div>
                </div>
            </div>
        </div>;
    }
}