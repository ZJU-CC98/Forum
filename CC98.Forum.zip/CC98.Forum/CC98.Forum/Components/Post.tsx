﻿import * as React from 'react';
import * as State from "../States/AppState"
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom';

import { match } from "react-router";
export class RouteComponent<TProps, TState, TMatch> extends React.Component<TProps, TState> {
    match: match<TMatch>;
    constructor(props, context) {
        super(props, context);
        this.match = props.match;
    }
}
export class Post extends RouteComponent<{}, {}, {}> {

    render() {
        return <Router>
            <div className="center" >
            <PostTopic/>
            <Reply/>

        </div>
        </Router>;
    }

}
export class Reply extends RouteComponent<{}, {}, {}>{
    render() {
        return <Router><div className="center" style={{ width:"1140px" }}>
            <Replier />
            <ReplyContent />
        </div>
        </Router>;
    }
}

export class Replier extends RouteComponent<{}, State.ReplierState, {}>{
    constructor(props, content) {
        super(props, content);
        this.state = {
            imgUrl: "/images/authorImg.jpg",
            timeImgUrl: "/images/clock.jpg",
            userName: "VayneTian",
            replyTime: Date(),
            topicsNumber: 999,
            level: 2,
        }
    }
    render() {
        return <div className="replyRoot">
            <div className="row" style={{ width: "1140px", display: "flex" }}>
                <div id="authorImg" ><img src={this.state.imgUrl}></img></div>
                <div className="column" id="rpymes">
                    <div className="row" id="replierMes">
                        <div style={{ marginLeft: "10px" }}><span>{this.state.level}L</span></div>
                        <div className="rpyClrodd" style={{ marginLeft: "10px" }}>{this.state.userName}</div>
                        <div id="topicsNumber" style={{ marginLeft: "10px" }}>贴数   <span className="rpyClrodd">{this.state.topicsNumber}</span> </div>
                    </div>
                    <div className="row">
                        <div id="clockimg"><img src={this.state.timeImgUrl} ></img></div>
                        <div><span className="timeProp">{this.state.replyTime}</span></div>
                    </div>
                </div>
                <div id="operation">
                    <button className="operation">引用</button>
                    <button className="operation">编辑</button>
                    <button className="operation">私信</button>
                    <button className="operation">举报</button>
                    <button className="operation">只看此用户</button>
                </div>
            </div></div>;
    }
}
export class PostTopic extends RouteComponent<{}, State.PostTopicState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            imgUrl: "/images/ads.jpg"
        }
    }

    render() {
        return <Router>
            <div className="root">
                <div className="essay">
                    <AuthorMessage />
                    <TopicTitle />
                    <div id="ads"><img src={this.state.imgUrl}></img></div>
                </div>
                <TopicContent />
                <TopicGood />
                <TopicVote />
            </div></Router>;
    }
}
export class AuthorMessage extends RouteComponent<{}, State.AuthorMessageState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            userName: "Mana",
            fansNumber: 233,
            imgUrl: "/images/authorImg.jpg"
        }
    }
    render() {
        return <div className="row" id="authormes">

            <div id="authorImg" ><img src={this.state.imgUrl}></img></div>
            <div className="column">
                <div className="row">
                    <div id="authorName"><p>{this.state.userName}</p></div>
                    <div id="fans"><p>粉丝</p></div>
                    <div id="authorFans"><p>{this.state.fansNumber}</p></div>
                </div>

                <div className="row">
                    <button id="watch">关注</button>
                    <button id="email">私信</button>
                </div>
            </div>
        </div>;
    }
}
export class TopicTitle extends RouteComponent<{}, State.TopicTitleState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            isNotice: true,
            isTop: true,
            title: "这是一个长长啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊的标题",
            tag: "女装/开车",
            time: "2017.8.12",
            likeNumber: 666,
            unlikeNumber: 233,
            viewTimes: 2366
        }
    }
    render() {
        return <div id="title">
            <div className="column" style={{ width: "520px" }}>
                <div id="essay1">
                    <div id="title1"> <span className="titleProp">{this.state.isTop ? "【置顶】" : ""}</span><span className="titleProp">{this.state.isNotice ? "【公告】" : ""} </span><span id="essayTitle">{this.state.title}</span></div>

                </div>
                <div className="row" id="essayProp">
                    <div id="essayGrow">
                        <div id="tags"><span className="tagProp tagSize">标签： {this.state.tag}</span><span className="tagProp"></span></div>
                        <div id="time"><img src="/images/clock.jpg" style={{ marginTop: "3px" }}></img> <span className="timeProp tagSize">{this.state.time}</span></div>
                        <div id="viewtimes"><span className="viewProp">★~★ </span> <span className="timeProp tagSize">{this.state.viewTimes}次</span></div>
                    </div>

                </div>
            </div>
            <div className="column" style={{ width: "100px" }}>
                <div className="row" style={{ marginTop: "20px" }}>
                    <div id="like"><span><button id="onlike">✰</button>  收藏文章</span></div>
                </div>
                <div className="row" style={{ marginTop: "20px" }}>
                    <div id="liked"><img src="/images/like.jpg"></img><span className="timeProp tagSize">{this.state.likeNumber}</span></div>
                    <div id="unliked"><img src="/images/unlike.jpg"></img><span className="timeProp tagSize">{this.state.unlikeNumber}</span></div>
                </div>
            </div>
        </div>;
    }
}
export class TopicContent extends RouteComponent<{}, State.ContentState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            likeNumber: 666,
            unlikeNumber: 233,
            signature: "where there is a will, there is a way.",
            content: "央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。</p><p>央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。",
        }
    }
    render() {
        return <div className="content">
            <div className="substance"><p>{this.state.content}</p></div>
            <div className="signature">{this.state.signature}</div>
            <div className="comment">
                <div id="commentlike"><button className="commentbutton">✰</button>  收藏文章</div>
                <div id="commentliked"><img src="/images/like.jpg"></img><span className="commentProp"> {this.state.likeNumber}</span></div>
                <div id="commentunliked"><img src="/images/unlike.jpg"></img><span className="commentProp"> {this.state.unlikeNumber}</span></div>
                <div id="commentlike"> <button className="commentbutton">   评分</button><button className="commentbutton">   编辑</button></div>
            </div>
        </div>;
    }
}
export class ReplyContent extends RouteComponent<{}, State.ContentState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            likeNumber: 2424,
            unlikeNumber: 4433,
            signature: "Lovelive!",
            content: "央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。</p><p>央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。",
        }
    }
    render() {
        return <div className="root">
            <div className="content">
                <div className="substance"><p>{this.state.content}</p></div>
                <div className="signature">{this.state.signature}</div>
                <div className="comment">

                    <div id="commentliked"><img src="/images/like.jpg"></img><span className="commentProp"> {this.state.likeNumber}</span></div>
                    <div id="commentunliked"><img src="/images/unlike.jpg"></img><span className="commentProp"> {this.state.unlikeNumber}</span></div>
                    <div id="commentlike"> <button className="commentbutton">   评分</button></div>
                </div>
            </div></div>;
    }
}
export class TopicGood extends RouteComponent<{}, State.TopicGoodState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            userName: "Mana",
            grade: 10,
            reward: 20,
            credit: "6666炒鸡赞",
            imgUrl: "/images/authorImg.jpg"
        }
    }
    render() {
        return <div className="good">
            <div id="userImage"><img src={this.state.imgUrl} ></img> </div>
            <div id="userName"><span>{this.state.userName}</span></div>
            <div id="grades"><span>评分 </span><span id="grade">+{this.state.grade}</span></div>
            <div id="reward"><span>赏金 </span><span id="money">{this.state.reward}</span><span>论坛币</span></div>
            <div id="credit"><span>{this.state.credit}</span></div>
        </div>;
    }
}

export class TopicVote extends RouteComponent<{}, State.TopicVoteState, {}> {
    constructor(props, content) {
        super(props, content);
        this.state = {
            option: "我认为他说的很对",
            votes: 60,
            totalVotes: 220,
            voted: false,
        }
    }
    render() {
        return <div className="vote">
            <div className="row"><input id="checkbox" type="checkbox" /> <span id="option" style={{ marginLeft: "15px" }}>{this.state.option} </span></div>
            <div className="row">
                <div className="progress">
                    <div className="voteResult"></div>
                </div>
                <span style={{ marginLeft: "15px" }}>{this.state.votes}</span>
                <span> ({this.state.votes / this.state.totalVotes * 100}%)</span>
            </div>
            <div style={{ marginLeft: "20px" }}>{this.state.voted ? <span>你已经投过票啦</span> : <button className="operation">投票</button>}</div>
        </div>;
    }
}