﻿import * as React from 'react';
import { AppState } from '../States/AppState';
import * as ReactDOM from 'react-dom';
import { match } from "react-router";
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom';
import { Post } from './post'
import { List } from './List'


export class RouteComponent<TProps, TState, TMatch> extends React.Component<TProps, TState> {
    match: match<TMatch>;
    constructor(props, context) {
        super(props, context);
        this.match = props.match;
    }
}

export class App extends RouteComponent<{}, AppState, {}> {

    render() {
        return <div><Router>
            <div style={{ backgroundColor: "#F5FAFD"}}><h1>Ashida Mana~</h1>
                <li><Link to="/post">moe moe</Link></li>
                <li><Link to="/list">meow</Link></li>

                <div className="announcement">
                    <div className="blueBar1">
                        <div className="listName">论坛公告</div>
                    </div>
                    <div className="announcementContent">
                        <div className="row" style={{ marginTop:"12px" }}><div className="announcementDate">[2017.08.17]</div><div className="announcementText">公告1</div><div className="announcementLink1">★详情点击★</div></div>
                        <div className="row" style={{ marginTop: "12px" }}><div className="announcementDate">[2017.08.17]</div><div className="announcementText">公告2</div><div className="announcementLink1">★详情点击★</div></div>
                        <div className="row" style={{ marginTop: "12px" }}><div className="announcementDate">[2017.08.17]</div><div className="announcementText">公告3</div><div className="announcementLink1">★详情点击★</div></div>
                        <div className="row" style={{ marginTop: "12px" }}>
                            <div className="announcementLink2">★广播台点歌通道★</div>
                            <div className="announcementLink2">★CC98抽卡游戏★</div>
                            <div className="announcementLink2">★CC98 Share★</div>
                            <div className="announcementLink2">★推荐阅读投稿★</div>
                            <div className="announcementLink2">★社团及学生组织用户认证申请★</div>
                            <div className="announcementLink2">★MyCC98 安卓客户端★</div>
                        </div>
                    </div>
                </div>



            <hr/>
            <Route exact path="/post" component={Post} />
            <Route exact path="/list" component={List} />
            </div>
        </Router></div>;
    }

}           

