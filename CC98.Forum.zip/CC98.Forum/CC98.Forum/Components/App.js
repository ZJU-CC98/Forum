"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var react_router_dom_1 = require("react-router-dom");
var post_1 = require("./post");
var List_1 = require("./List");
var RouteComponent = (function (_super) {
    __extends(RouteComponent, _super);
    function RouteComponent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.match = props.match;
        return _this;
    }
    return RouteComponent;
}(React.Component));
exports.RouteComponent = RouteComponent;
var App = (function (_super) {
    __extends(App, _super);
    function App() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    App.prototype.render = function () {
        return React.createElement("div", null,
            React.createElement(react_router_dom_1.BrowserRouter, null,
                React.createElement("div", { style: { backgroundColor: "#F5FAFD" } },
                    React.createElement("h1", null, "Ashida Mana~"),
                    React.createElement("li", null,
                        React.createElement(react_router_dom_1.Link, { to: "/post" }, "moe moe")),
                    React.createElement("li", null,
                        React.createElement(react_router_dom_1.Link, { to: "/list" }, "meow")),
                    React.createElement("div", { className: "announcement" },
                        React.createElement("div", { className: "blueBar1" },
                            React.createElement("div", { className: "listName" }, "\u8BBA\u575B\u516C\u544A")),
                        React.createElement("div", { className: "announcementContent" },
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementDate" }, "[2017.08.17]"),
                                React.createElement("div", { className: "announcementText" }, "\u516C\u544A1"),
                                React.createElement("div", { className: "announcementLink1" }, "\u2605\u8BE6\u60C5\u70B9\u51FB\u2605")),
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementDate" }, "[2017.08.17]"),
                                React.createElement("div", { className: "announcementText" }, "\u516C\u544A2"),
                                React.createElement("div", { className: "announcementLink1" }, "\u2605\u8BE6\u60C5\u70B9\u51FB\u2605")),
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementDate" }, "[2017.08.17]"),
                                React.createElement("div", { className: "announcementText" }, "\u516C\u544A3"),
                                React.createElement("div", { className: "announcementLink1" }, "\u2605\u8BE6\u60C5\u70B9\u51FB\u2605")),
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementLink2" }, "\u2605\u5E7F\u64AD\u53F0\u70B9\u6B4C\u901A\u9053\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605CC98\u62BD\u5361\u6E38\u620F\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605CC98 Share\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605\u63A8\u8350\u9605\u8BFB\u6295\u7A3F\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605\u793E\u56E2\u53CA\u5B66\u751F\u7EC4\u7EC7\u7528\u6237\u8BA4\u8BC1\u7533\u8BF7\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605MyCC98 \u5B89\u5353\u5BA2\u6237\u7AEF\u2605")))),
                    React.createElement("hr", null),
                    React.createElement(react_router_dom_1.Route, { exact: true, path: "/post", component: post_1.Post }),
                    React.createElement(react_router_dom_1.Route, { exact: true, path: "/list", component: List_1.List }))));
    };
    return App;
}(RouteComponent));
exports.App = App;
//# sourceMappingURL=App.js.map