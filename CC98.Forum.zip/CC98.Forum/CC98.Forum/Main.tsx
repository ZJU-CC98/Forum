﻿import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as $ from 'jquery';

import { App } from './Components/App';

// 显示应用程序核心内容
ReactDOM.render(<App />, document.getElementById('root'));