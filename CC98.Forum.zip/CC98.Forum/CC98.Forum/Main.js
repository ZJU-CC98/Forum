"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var ReactDOM = require("react-dom");
var App_1 = require("./Components/App");
// 显示应用程序核心内容
ReactDOM.render(React.createElement(App_1.App, null), document.getElementById('root'));
//# sourceMappingURL=Main.js.map