"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MessageMatch = (function () {
    function MessageMatch() {
    }
    return MessageMatch;
}());
exports.MessageMatch = MessageMatch;
//# sourceMappingURL=Match.js.map