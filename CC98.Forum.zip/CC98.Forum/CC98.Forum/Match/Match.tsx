﻿export class MessageMatch {
    page;
}