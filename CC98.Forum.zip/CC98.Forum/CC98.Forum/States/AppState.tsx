﻿/**
 * 表示应用程序的状态。
 */
export class AppState {

}
/**
 * 投票状态 
 */
export class TopicVoteState {
    
    votes: number;
    totalVotes: number;
    option: string;
    voted: boolean;
}
/**
 * 发帖内容状态
 */
export class PostTopicState {
    imgUrl: string;
}
/**
 * 作者信息状态
 */
export class AuthorMessageState {
    imgUrl: string;
    userName: string;
    fansNumber: number;
}
/**
 * 题目信息状态
 */
export class TopicTitleState {
    title: string;
    isTop: boolean;
    isNotice: boolean;
    tag: string;
    likeNumber: number;
    unlikeNumber: number;
    time: string;
    viewTimes: number;
}
/**
 * 文章内容
 */
export class ContentState {
    content: string;
    likeNumber: number;
    unlikeNumber: number;
    signature: string;
}
/**
 * 点赞信息状态
 */
export class TopicGoodState {
    imgUrl: string;
    userName: string;
    grade: number;
    reward: number;
    credit: string;
}
/**
 * 回复者状态
 */
export class ReplierState {
    userName: string;
    level: number;
    topicsNumber: number;
    replyTime: string;
    imgUrl: string;
    timeImgUrl: string;
}
export class ListHeadState {
    imgUrl: string;
    listName: string;
    todayTopics: number;
    totalTopics: number;
    adsUrl: string;
    listManager: string;
    todayPosts: number;
}
export class ListNoticeState {
    notice: string;
}
export class ListTagState {
    tags: Object;
}
export class ListContentState {
    items;
    curPage;
}
export class TopicTitleAndContentState {
  /*  constructor(title, authorName, lastReply) {
        this.authorName = authorName;
        this.lastReply = lastReply;
        this.title = title;
    }*/
    constructor(title, authorName) {
        this.authorName = authorName;
        this.title = title;
    }

    likeNumber: number;
    unlikeNumber: number;
    commentNumber: number;
    authorName: string;
    title: string;
    lastReply: string;
    
}
export class ListPagerState {
    Pager;
    curPage: number;
}
export class PagerState {
    constructor(page: number) {
        this.pageNumber = page;
    }
    pageNumber: number;
}