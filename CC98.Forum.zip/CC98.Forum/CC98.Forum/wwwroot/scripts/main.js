/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = React;

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = ReactRouterDOM;

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var React = __webpack_require__(0);
var Module = __webpack_require__(8);
var react_router_dom_1 = __webpack_require__(1);
var RouteComponent = (function (_super) {
    __extends(RouteComponent, _super);
    function RouteComponent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.match = props.match;
        return _this;
    }
    return RouteComponent;
}(React.Component));
exports.RouteComponent = RouteComponent;
var List = (function (_super) {
    __extends(List, _super);
    function List() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    List.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { id: "listRoot" },
                React.createElement(ListHead, null),
                React.createElement(ListNotice, null),
                React.createElement(react_router_dom_1.Route, { component: ListButtonAndPager }),
                React.createElement(ListTag, null),
                React.createElement(react_router_dom_1.Route, { path: "/list/:page", component: ListContent })));
    };
    return List;
}(RouteComponent));
exports.List = List;
var ListHead = (function (_super) {
    __extends(ListHead, _super);
    function ListHead(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            imgUrl: "/images/ListImg.jpg",
            listName: "学术信息",
            todayTopics: 210,
            totalTopics: 12000,
            adsUrl: "/images/ads.jpg",
            listManager: "Dearkano",
            todayPosts: 90,
        };
        return _this;
    }
    ListHead.prototype.render = function () {
        return React.createElement("div", { className: "column", style: { width: "1140px", } },
            React.createElement("div", { className: "row", style: { flexDirection: "row", justifyContent: "space-between", width: "1140px" } },
                React.createElement("div", { style: { flexgrow: "1", flexDirection: "row", display: "flex" } },
                    React.createElement("div", { id: "ListImg" },
                        React.createElement("img", { src: this.state.imgUrl })),
                    React.createElement("div", { className: "column", style: { marginTop: "20px", marginLeft: "10px" } },
                        React.createElement("div", { style: { marginTop: "10px" } },
                            React.createElement("span", null, "\u4ECA\u65E5\u5E16\u6570"),
                            React.createElement("span", null, this.state.todayPosts)),
                        React.createElement("div", { style: { marginTop: "10px" } },
                            React.createElement("span", null, "\u4ECA\u65E5\u4E3B\u9898"),
                            React.createElement("span", null, this.state.todayTopics)),
                        React.createElement("div", { style: { marginTop: "10px" } },
                            React.createElement("span", null, "\u603B\u4E3B\u9898"),
                            React.createElement("span", null, this.state.totalTopics)))),
                React.createElement("div", { className: "column", style: { flexgrow: "0" } },
                    React.createElement("div", { id: "like" },
                        React.createElement("button", { style: { border: "none", color: "#F5FAFC" } }, "\u2730"),
                        "  \u6536\u85CF\u7248\u9762"),
                    React.createElement("div", null,
                        React.createElement("img", { src: this.state.adsUrl, style: { width: "250px", height: "60px" } })))),
            React.createElement("div", { className: "row", style: { marginTop: "5px" } },
                React.createElement("span", null, "\u7248\u4E3B : "),
                React.createElement("span", { style: { marginLeft: "5px" } }, this.state.listManager)));
    };
    return ListHead;
}(RouteComponent));
exports.ListHead = ListHead;
var ListNotice = (function (_super) {
    __extends(ListNotice, _super);
    function ListNotice(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.state = {
            notice: "1. 请大家首先阅读心灵之约版规再发帖，如有违规不接受pm卖萌求情；2. 诚征新版主，请去论坛事务版搜之前的版面负责人申请帖并遵循格式发帖，如有不明可以站短站务组组长咨询。3. 不要留联系方式！不要留联系方式！不要留联系方式！重要的事说三遍！，留任何联系方式tp1000天。 4. 更新了版规，增加了tp规则：成功诱导对方留联系方式的，tp1000天；修订了锁沉规则：有意义言之有物、希望继续讨论的长篇读后感将给予保留。5. 请理性讨论，不要人身攻击。违者tp1天起，累犯或严重的，上不封顶。",
        };
        return _this;
    }
    ListNotice.prototype.render = function () {
        return React.createElement("div", { className: "notice", style: { marginTop: "10px" } },
            React.createElement("div", { id: "noticeName" },
                React.createElement("span", { style: { marginLeft: "15px", marginTop: "7px", color: "#FFFFFF" } }, "\u672C\u7248\u516C\u544A")),
            React.createElement("span", { style: { marginLeft: "15px", marginTop: "15px", marginRight: "15px" } }, this.state.notice));
    };
    return ListNotice;
}(RouteComponent));
exports.ListNotice = ListNotice;
var ListButtonAndPager = (function (_super) {
    __extends(ListButtonAndPager, _super);
    function ListButtonAndPager(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.state = {
            Pager: [],
            curPage: 1
        };
        return _this;
    }
    ListButtonAndPager.prototype.componentDidMount = function () {
        var curPage = this.match.params.page;
        console.log("cur=" + curPage);
        var pager = Module.getPager(curPage);
        if (curPage == undefined) {
            curPage = 1;
        }
        this.setState({
            Pager: pager,
            curPage: curPage
        });
    };
    ListButtonAndPager.prototype.render = function () {
        var pager = [];
        pager = this.state.Pager.map(Module.pageNumber);
        var lastPage = this.state.curPage - 1;
        var nextPage = this.state.curPage + 1;
        var lastPageUrl = "/list/page=" + lastPage;
        var nextPageUrl = "/list/page=" + nextPage;
        return React.createElement("div", { className: "row", style: { width: "1140px", height: "50px", marginTop: "15px", justifyContent: "space-between", borderBottom: " #EAEAEA solid thin dashed", alignItems: "flex-end" } },
            React.createElement("div", null,
                React.createElement("button", { className: "postTopic" }, "\u53D1\u4E3B\u9898"),
                React.createElement("button", { className: "postVote" }, "\u53D1\u6295\u7968")),
            React.createElement("div", { id: "pager" },
                React.createElement(react_router_dom_1.Link, { id: "lastPage", className: "pager", to: lastPageUrl }, "<"),
                React.createElement("div", { className: "row" }, pager),
                React.createElement(react_router_dom_1.Link, { id: "nextPage", className: "pager", to: nextPageUrl }, ">")));
    };
    return ListButtonAndPager;
}(RouteComponent));
exports.ListButtonAndPager = ListButtonAndPager;
var ListTag = (function (_super) {
    __extends(ListTag, _super);
    function ListTag(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.state = {
            tags: Array(["ow", ["lol", ["dota", ["csgo"]]]]),
        };
        return _this;
    }
    ListTag.prototype.render = function () {
        return React.createElement("div", { style: { display: "flex", flexDirection: "row", justifyContent: "flex-start", width: "1140px", borderTop: "dashed #EAEAEA solid thin", marginTop: "25px", marginBottom: "25px" } },
            React.createElement("div", { className: "row" },
                "  ",
                React.createElement("button", { id: "tagButton" }, "\u5168\u90E8"),
                React.createElement("button", { className: "chooseTag" },
                    "dota ",
                    React.createElement("span", { className: "tagNumber" }, "1234")),
                React.createElement("button", { className: "chooseTag" },
                    "csgo ",
                    React.createElement("span", { className: "tagNumber" }, "5687"))));
    };
    return ListTag;
}(RouteComponent));
exports.ListTag = ListTag;
var ListContent = (function (_super) {
    __extends(ListContent, _super);
    function ListContent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.state = {
            items: [],
            curPage: 1
        };
        return _this;
    }
    ListContent.prototype.componentDidMount = function () {
        return __awaiter(this, void 0, void 0, function () {
            var curPage, i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        curPage = this.props.match.params.page;
                        if (curPage == undefined) {
                            curPage = 1;
                        }
                        return [4 /*yield*/, Module.getBoardTopic(curPage)];
                    case 1:
                        i = _a.sent();
                        console.log(i);
                        this.setState({
                            items: i,
                            curPage: curPage
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ListContent.prototype.componentDidUpdate = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                console.log("didUpdate");
                console.log(this.state.items.map(Module.convertHotTopic));
                return [2 /*return*/];
            });
        });
    };
    ListContent.prototype.componentWillUpdate = function (nextProps, nextState) {
        console.log("willUpdate");
        console.log(this.state.items);
        console.log(nextState.items);
    };
    ListContent.prototype.componentWillReceiveProps = function (nextProps) {
        return __awaiter(this, void 0, void 0, function () {
            var curPage, i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        curPage = nextProps.match.params.page;
                        if (curPage == undefined) {
                            curPage = 1;
                        }
                        return [4 /*yield*/, Module.getBoardTopic(curPage)];
                    case 1:
                        i = _a.sent();
                        console.log(i);
                        this.setState({
                            items: i
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    ListContent.prototype.render = function () {
        var items = this.state.items.map(Module.convertHotTopic);
        console.log("final");
        console.log(items);
        return React.createElement("div", { className: "listContent " },
            React.createElement("div", { className: "row", style: { justifyContent: "space-between", } },
                React.createElement("div", { className: "row", style: { height: "40px" } },
                    React.createElement("button", { className: "listContentTag" }, "\u5168\u90E8"),
                    React.createElement("button", { className: "listContentTag" }, "\u7CBE\u534E"),
                    React.createElement("button", { className: "listContentTag" }, "\u6700\u70ED")),
                React.createElement("div", { className: "row", style: { height: "40px", alignItems: "center" } },
                    React.createElement("div", { style: { marginRight: "152px", marginLeft: "15px" } },
                        React.createElement("span", null, "\u4F5C\u8005")),
                    React.createElement("div", { style: { marginRight: "85px", marginLeft: "15px" } },
                        React.createElement("span", null, "\u6700\u540E\u53D1\u8868")))),
            React.createElement("div", null,
                React.createElement(TopicContentSet, { items: items })));
    };
    return ListContent;
}(RouteComponent));
exports.ListContent = ListContent;
var TopicContentSet = (function (_super) {
    __extends(TopicContentSet, _super);
    function TopicContentSet() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TopicContentSet.prototype.render = function () {
        return React.createElement("div", null, this.props.items);
    };
    return TopicContentSet;
}(RouteComponent));
exports.TopicContentSet = TopicContentSet;
var TopicTitleAndContent = (function (_super) {
    __extends(TopicTitleAndContent, _super);
    function TopicTitleAndContent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.state = {
            title: _this.props.title,
            authorName: _this.props.authorName,
            likeNumber: 123,
            unlikeNumber: 11,
            commentNumber: 214,
            lastReply: "Dearkano 2017-2-2",
        };
        return _this;
    }
    TopicTitleAndContent.prototype.render = function () {
        return React.createElement("div", { id: "changeColor" },
            React.createElement("div", { className: "row topicInList" },
                React.createElement("div", { style: { marginLeft: "20px", } },
                    " ",
                    React.createElement("span", null, this.state.title)),
                React.createElement("div", { className: "row" },
                    React.createElement("div", { style: { marginRight: "10px", marginLeft: "15px", width: "80px" } },
                        " ",
                        React.createElement("span", null, this.state.authorName)),
                    React.createElement("div", { className: "row", style: { flexDirection: "row", alignItems: "flex-end" } },
                        React.createElement("div", { id: "liked" },
                            React.createElement("img", { src: this.props.likeImgUrl }),
                            React.createElement("span", { className: "timeProp tagSize" }, this.state.likeNumber)),
                        React.createElement("div", { id: "unliked" },
                            React.createElement("img", { src: this.props.unlikeImgUrl }),
                            React.createElement("span", { className: "timeProp tagSize" }, this.state.unlikeNumber)),
                        React.createElement("div", { id: "commentsAmount" },
                            React.createElement("img", { src: this.props.commentImgUrl }),
                            React.createElement("span", { className: "timeProp tagSize" }, this.state.commentNumber))),
                    React.createElement("div", { id: "lastReply" },
                        React.createElement("span", null, this.state.lastReply)))));
    };
    return TopicTitleAndContent;
}(RouteComponent));
exports.TopicTitleAndContent = TopicTitleAndContent;
//# sourceMappingURL=List.js.map

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(4);
module.exports = __webpack_require__(10);


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var React = __webpack_require__(0);
var ReactDOM = __webpack_require__(5);
var App_1 = __webpack_require__(6);
// 显示应用程序核心内容
ReactDOM.render(React.createElement(App_1.App, null), document.getElementById('root'));


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = ReactDOM;

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = __webpack_require__(0);
var react_router_dom_1 = __webpack_require__(1);
var post_1 = __webpack_require__(7);
var List_1 = __webpack_require__(2);
var RouteComponent = (function (_super) {
    __extends(RouteComponent, _super);
    function RouteComponent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.match = props.match;
        return _this;
    }
    return RouteComponent;
}(React.Component));
exports.RouteComponent = RouteComponent;
var App = (function (_super) {
    __extends(App, _super);
    function App() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    App.prototype.render = function () {
        return React.createElement("div", null,
            React.createElement(react_router_dom_1.BrowserRouter, null,
                React.createElement("div", { style: { backgroundColor: "#F5FAFD" } },
                    React.createElement("h1", null, "Ashida Mana~"),
                    React.createElement("li", null,
                        React.createElement(react_router_dom_1.Link, { to: "/post" }, "moe moe")),
                    React.createElement("li", null,
                        React.createElement(react_router_dom_1.Link, { to: "/list" }, "meow")),
                    React.createElement("div", { className: "announcement" },
                        React.createElement("div", { className: "blueBar1" },
                            React.createElement("div", { className: "listName" }, "\u8BBA\u575B\u516C\u544A")),
                        React.createElement("div", { className: "announcementContent" },
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementDate" }, "[2017.08.17]"),
                                React.createElement("div", { className: "announcementText" }, "\u516C\u544A1"),
                                React.createElement("div", { className: "announcementLink1" }, "\u2605\u8BE6\u60C5\u70B9\u51FB\u2605")),
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementDate" }, "[2017.08.17]"),
                                React.createElement("div", { className: "announcementText" }, "\u516C\u544A2"),
                                React.createElement("div", { className: "announcementLink1" }, "\u2605\u8BE6\u60C5\u70B9\u51FB\u2605")),
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementDate" }, "[2017.08.17]"),
                                React.createElement("div", { className: "announcementText" }, "\u516C\u544A3"),
                                React.createElement("div", { className: "announcementLink1" }, "\u2605\u8BE6\u60C5\u70B9\u51FB\u2605")),
                            React.createElement("div", { className: "row", style: { marginTop: "12px" } },
                                React.createElement("div", { className: "announcementLink2" }, "\u2605\u5E7F\u64AD\u53F0\u70B9\u6B4C\u901A\u9053\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605CC98\u62BD\u5361\u6E38\u620F\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605CC98 Share\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605\u63A8\u8350\u9605\u8BFB\u6295\u7A3F\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605\u793E\u56E2\u53CA\u5B66\u751F\u7EC4\u7EC7\u7528\u6237\u8BA4\u8BC1\u7533\u8BF7\u2605"),
                                React.createElement("div", { className: "announcementLink2" }, "\u2605MyCC98 \u5B89\u5353\u5BA2\u6237\u7AEF\u2605")))),
                    React.createElement("hr", null),
                    React.createElement(react_router_dom_1.Route, { exact: true, path: "/post", component: post_1.Post }),
                    React.createElement(react_router_dom_1.Route, { exact: true, path: "/list", component: List_1.List }))));
    };
    return App;
}(RouteComponent));
exports.App = App;
//# sourceMappingURL=App.js.map

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = __webpack_require__(0);
var react_router_dom_1 = __webpack_require__(1);
var RouteComponent = (function (_super) {
    __extends(RouteComponent, _super);
    function RouteComponent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.match = props.match;
        return _this;
    }
    return RouteComponent;
}(React.Component));
exports.RouteComponent = RouteComponent;
var Post = (function (_super) {
    __extends(Post, _super);
    function Post() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Post.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { className: "center" },
                React.createElement(PostTopic, null),
                React.createElement(Reply, null)));
    };
    return Post;
}(RouteComponent));
exports.Post = Post;
var Reply = (function (_super) {
    __extends(Reply, _super);
    function Reply() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Reply.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { className: "center", style: { width: "1140px" } },
                React.createElement(Replier, null),
                React.createElement(ReplyContent, null)));
    };
    return Reply;
}(RouteComponent));
exports.Reply = Reply;
var Replier = (function (_super) {
    __extends(Replier, _super);
    function Replier(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            imgUrl: "/images/authorImg.jpg",
            timeImgUrl: "/images/clock.jpg",
            userName: "VayneTian",
            replyTime: Date(),
            topicsNumber: 999,
            level: 2,
        };
        return _this;
    }
    Replier.prototype.render = function () {
        return React.createElement("div", { className: "replyRoot" },
            React.createElement("div", { className: "row", style: { width: "1140px", display: "flex" } },
                React.createElement("div", { id: "authorImg" },
                    React.createElement("img", { src: this.state.imgUrl })),
                React.createElement("div", { className: "column", id: "rpymes" },
                    React.createElement("div", { className: "row", id: "replierMes" },
                        React.createElement("div", { style: { marginLeft: "10px" } },
                            React.createElement("span", null,
                                this.state.level,
                                "L")),
                        React.createElement("div", { className: "rpyClrodd", style: { marginLeft: "10px" } }, this.state.userName),
                        React.createElement("div", { id: "topicsNumber", style: { marginLeft: "10px" } },
                            "\u8D34\u6570   ",
                            React.createElement("span", { className: "rpyClrodd" }, this.state.topicsNumber),
                            " ")),
                    React.createElement("div", { className: "row" },
                        React.createElement("div", { id: "clockimg" },
                            React.createElement("img", { src: this.state.timeImgUrl })),
                        React.createElement("div", null,
                            React.createElement("span", { className: "timeProp" }, this.state.replyTime)))),
                React.createElement("div", { id: "operation" },
                    React.createElement("button", { className: "operation" }, "\u5F15\u7528"),
                    React.createElement("button", { className: "operation" }, "\u7F16\u8F91"),
                    React.createElement("button", { className: "operation" }, "\u79C1\u4FE1"),
                    React.createElement("button", { className: "operation" }, "\u4E3E\u62A5"),
                    React.createElement("button", { className: "operation" }, "\u53EA\u770B\u6B64\u7528\u6237"))));
    };
    return Replier;
}(RouteComponent));
exports.Replier = Replier;
var PostTopic = (function (_super) {
    __extends(PostTopic, _super);
    function PostTopic(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            imgUrl: "/images/ads.jpg"
        };
        return _this;
    }
    PostTopic.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { className: "root" },
                React.createElement("div", { className: "essay" },
                    React.createElement(AuthorMessage, null),
                    React.createElement(TopicTitle, null),
                    React.createElement("div", { id: "ads" },
                        React.createElement("img", { src: this.state.imgUrl }))),
                React.createElement(TopicContent, null),
                React.createElement(TopicGood, null),
                React.createElement(TopicVote, null)));
    };
    return PostTopic;
}(RouteComponent));
exports.PostTopic = PostTopic;
var AuthorMessage = (function (_super) {
    __extends(AuthorMessage, _super);
    function AuthorMessage(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            userName: "Mana",
            fansNumber: 233,
            imgUrl: "/images/authorImg.jpg"
        };
        return _this;
    }
    AuthorMessage.prototype.render = function () {
        return React.createElement("div", { className: "row", id: "authormes" },
            React.createElement("div", { id: "authorImg" },
                React.createElement("img", { src: this.state.imgUrl })),
            React.createElement("div", { className: "column" },
                React.createElement("div", { className: "row" },
                    React.createElement("div", { id: "authorName" },
                        React.createElement("p", null, this.state.userName)),
                    React.createElement("div", { id: "fans" },
                        React.createElement("p", null, "\u7C89\u4E1D")),
                    React.createElement("div", { id: "authorFans" },
                        React.createElement("p", null, this.state.fansNumber))),
                React.createElement("div", { className: "row" },
                    React.createElement("button", { id: "watch" }, "\u5173\u6CE8"),
                    React.createElement("button", { id: "email" }, "\u79C1\u4FE1"))));
    };
    return AuthorMessage;
}(RouteComponent));
exports.AuthorMessage = AuthorMessage;
var TopicTitle = (function (_super) {
    __extends(TopicTitle, _super);
    function TopicTitle(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            isNotice: true,
            isTop: true,
            title: "这是一个长长啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊的标题",
            tag: "女装/开车",
            time: "2017.8.12",
            likeNumber: 666,
            unlikeNumber: 233,
            viewTimes: 2366
        };
        return _this;
    }
    TopicTitle.prototype.render = function () {
        return React.createElement("div", { id: "title" },
            React.createElement("div", { className: "column", style: { width: "520px" } },
                React.createElement("div", { id: "essay1" },
                    React.createElement("div", { id: "title1" },
                        " ",
                        React.createElement("span", { className: "titleProp" }, this.state.isTop ? "【置顶】" : ""),
                        React.createElement("span", { className: "titleProp" },
                            this.state.isNotice ? "【公告】" : "",
                            " "),
                        React.createElement("span", { id: "essayTitle" }, this.state.title))),
                React.createElement("div", { className: "row", id: "essayProp" },
                    React.createElement("div", { id: "essayGrow" },
                        React.createElement("div", { id: "tags" },
                            React.createElement("span", { className: "tagProp tagSize" },
                                "\u6807\u7B7E\uFF1A ",
                                this.state.tag),
                            React.createElement("span", { className: "tagProp" })),
                        React.createElement("div", { id: "time" },
                            React.createElement("img", { src: "/images/clock.jpg", style: { marginTop: "3px" } }),
                            " ",
                            React.createElement("span", { className: "timeProp tagSize" }, this.state.time)),
                        React.createElement("div", { id: "viewtimes" },
                            React.createElement("span", { className: "viewProp" }, "\u2605~\u2605 "),
                            " ",
                            React.createElement("span", { className: "timeProp tagSize" },
                                this.state.viewTimes,
                                "\u6B21"))))),
            React.createElement("div", { className: "column", style: { width: "100px" } },
                React.createElement("div", { className: "row", style: { marginTop: "20px" } },
                    React.createElement("div", { id: "like" },
                        React.createElement("span", null,
                            React.createElement("button", { id: "onlike" }, "\u2730"),
                            "  \u6536\u85CF\u6587\u7AE0"))),
                React.createElement("div", { className: "row", style: { marginTop: "20px" } },
                    React.createElement("div", { id: "liked" },
                        React.createElement("img", { src: "/images/like.jpg" }),
                        React.createElement("span", { className: "timeProp tagSize" }, this.state.likeNumber)),
                    React.createElement("div", { id: "unliked" },
                        React.createElement("img", { src: "/images/unlike.jpg" }),
                        React.createElement("span", { className: "timeProp tagSize" }, this.state.unlikeNumber)))));
    };
    return TopicTitle;
}(RouteComponent));
exports.TopicTitle = TopicTitle;
var TopicContent = (function (_super) {
    __extends(TopicContent, _super);
    function TopicContent(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            likeNumber: 666,
            unlikeNumber: 233,
            signature: "where there is a will, there is a way.",
            content: "央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。</p><p>央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。",
        };
        return _this;
    }
    TopicContent.prototype.render = function () {
        return React.createElement("div", { className: "content" },
            React.createElement("div", { className: "substance" },
                React.createElement("p", null, this.state.content)),
            React.createElement("div", { className: "signature" }, this.state.signature),
            React.createElement("div", { className: "comment" },
                React.createElement("div", { id: "commentlike" },
                    React.createElement("button", { className: "commentbutton" }, "\u2730"),
                    "  \u6536\u85CF\u6587\u7AE0"),
                React.createElement("div", { id: "commentliked" },
                    React.createElement("img", { src: "/images/like.jpg" }),
                    React.createElement("span", { className: "commentProp" },
                        " ",
                        this.state.likeNumber)),
                React.createElement("div", { id: "commentunliked" },
                    React.createElement("img", { src: "/images/unlike.jpg" }),
                    React.createElement("span", { className: "commentProp" },
                        " ",
                        this.state.unlikeNumber)),
                React.createElement("div", { id: "commentlike" },
                    " ",
                    React.createElement("button", { className: "commentbutton" }, "   \u8BC4\u5206"),
                    React.createElement("button", { className: "commentbutton" }, "   \u7F16\u8F91"))));
    };
    return TopicContent;
}(RouteComponent));
exports.TopicContent = TopicContent;
var ReplyContent = (function (_super) {
    __extends(ReplyContent, _super);
    function ReplyContent(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            likeNumber: 2424,
            unlikeNumber: 4433,
            signature: "Lovelive!",
            content: "央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。</p><p>央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。",
        };
        return _this;
    }
    ReplyContent.prototype.render = function () {
        return React.createElement("div", { className: "root" },
            React.createElement("div", { className: "content" },
                React.createElement("div", { className: "substance" },
                    React.createElement("p", null, this.state.content)),
                React.createElement("div", { className: "signature" }, this.state.signature),
                React.createElement("div", { className: "comment" },
                    React.createElement("div", { id: "commentliked" },
                        React.createElement("img", { src: "/images/like.jpg" }),
                        React.createElement("span", { className: "commentProp" },
                            " ",
                            this.state.likeNumber)),
                    React.createElement("div", { id: "commentunliked" },
                        React.createElement("img", { src: "/images/unlike.jpg" }),
                        React.createElement("span", { className: "commentProp" },
                            " ",
                            this.state.unlikeNumber)),
                    React.createElement("div", { id: "commentlike" },
                        " ",
                        React.createElement("button", { className: "commentbutton" }, "   \u8BC4\u5206")))));
    };
    return ReplyContent;
}(RouteComponent));
exports.ReplyContent = ReplyContent;
var TopicGood = (function (_super) {
    __extends(TopicGood, _super);
    function TopicGood(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            userName: "Mana",
            grade: 10,
            reward: 20,
            credit: "6666炒鸡赞",
            imgUrl: "/images/authorImg.jpg"
        };
        return _this;
    }
    TopicGood.prototype.render = function () {
        return React.createElement("div", { className: "good" },
            React.createElement("div", { id: "userImage" },
                React.createElement("img", { src: this.state.imgUrl }),
                " "),
            React.createElement("div", { id: "userName" },
                React.createElement("span", null, this.state.userName)),
            React.createElement("div", { id: "grades" },
                React.createElement("span", null, "\u8BC4\u5206 "),
                React.createElement("span", { id: "grade" },
                    "+",
                    this.state.grade)),
            React.createElement("div", { id: "reward" },
                React.createElement("span", null, "\u8D4F\u91D1 "),
                React.createElement("span", { id: "money" }, this.state.reward),
                React.createElement("span", null, "\u8BBA\u575B\u5E01")),
            React.createElement("div", { id: "credit" },
                React.createElement("span", null, this.state.credit)));
    };
    return TopicGood;
}(RouteComponent));
exports.TopicGood = TopicGood;
var TopicVote = (function (_super) {
    __extends(TopicVote, _super);
    function TopicVote(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            option: "我认为他说的很对",
            votes: 60,
            totalVotes: 220,
            voted: false,
        };
        return _this;
    }
    TopicVote.prototype.render = function () {
        return React.createElement("div", { className: "vote" },
            React.createElement("div", { className: "row" },
                React.createElement("input", { id: "checkbox", type: "checkbox" }),
                " ",
                React.createElement("span", { id: "option", style: { marginLeft: "15px" } },
                    this.state.option,
                    " ")),
            React.createElement("div", { className: "row" },
                React.createElement("div", { className: "progress" },
                    React.createElement("div", { className: "voteResult" })),
                React.createElement("span", { style: { marginLeft: "15px" } }, this.state.votes),
                React.createElement("span", null,
                    " (",
                    this.state.votes / this.state.totalVotes * 100,
                    "%)")),
            React.createElement("div", { style: { marginLeft: "20px" } }, this.state.voted ? React.createElement("span", null, "\u4F60\u5DF2\u7ECF\u6295\u8FC7\u7968\u5566") : React.createElement("button", { className: "operation" }, "\u6295\u7968")));
    };
    return TopicVote;
}(RouteComponent));
exports.TopicVote = TopicVote;
//# sourceMappingURL=post.js.map

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var State = __webpack_require__(9);
var React = __webpack_require__(0);
var List_1 = __webpack_require__(2);
var react_router_dom_1 = __webpack_require__(1);
function getData() {
    return __awaiter(this, void 0, void 0, function () {
        var hottopics, response, data, i, items;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    hottopics = [];
                    return [4 /*yield*/, fetch('http://api.cc98.org/Topic/Hot')];
                case 1:
                    response = _a.sent();
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    for (i = 0; i < 10; i++) {
                        hottopics[i] = new State.TopicTitleAndContentState(data[i].title, data[i].authorName || '匿名');
                    }
                    items = hottopics.map(convertHotTopic);
                    return [2 /*return*/, items];
            }
        });
    });
}
exports.getData = getData;
function getPager(curPage) {
    var pages = [];
    if (curPage == undefined || curPage == 1 || curPage == 2) {
        pages[0] = new State.PagerState(1);
        pages[1] = new State.PagerState(2);
        pages[2] = new State.PagerState(3);
        pages[3] = new State.PagerState(4);
        pages[4] = new State.PagerState(5);
    }
    else {
        pages[0] = new State.PagerState(curPage - 2);
        pages[1] = new State.PagerState(curPage - 1);
        pages[2] = new State.PagerState(curPage);
        pages[3] = new State.PagerState(curPage + 1);
        pages[4] = new State.PagerState(curPage + 2);
    }
    return pages;
}
exports.getPager = getPager;
function getBoardTopic(curPage) {
    return __awaiter(this, void 0, void 0, function () {
        var startPage, endPage, boardtopics, response, data, i;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    startPage = (curPage - 1) * 10 + 1;
                    endPage = curPage * 10;
                    boardtopics = [];
                    return [4 /*yield*/, fetch('http://api.cc98.org/Topic/Board/493', { headers: { Range: "bytes=" + startPage + "-" + endPage } })];
                case 1:
                    response = _a.sent();
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    for (i = 0; i < 10; i++) {
                        boardtopics[i] = new State.TopicTitleAndContentState(data[i].title, data[i].authorName || '匿名');
                    }
                    return [2 /*return*/, boardtopics];
            }
        });
    });
}
exports.getBoardTopic = getBoardTopic;
function convertHotTopic(item) {
    return React.createElement(List_1.TopicTitleAndContent, { title: item.title, authorName: item.authorName, likeImgUrl: "/images/like.jpg", unlikeImgUrl: "/images/unlike.jpg", commentImgUrl: "/images/comment.jpg" });
}
exports.convertHotTopic = convertHotTopic;
function pageNumber(pageNumber) {
    var pageUrl = "/list/" + pageNumber.pageNumber;
    return React.createElement("div", null,
        " ",
        React.createElement(react_router_dom_1.Link, { className: "pager", style: {
                width: "30px",
                height: "25px"
            }, to: pageUrl }, pageNumber.pageNumber));
}
exports.pageNumber = pageNumber;
//# sourceMappingURL=module.js.map

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 表示应用程序的状态。
 */
var AppState = (function () {
    function AppState() {
    }
    return AppState;
}());
exports.AppState = AppState;
/**
 * 投票状态
 */
var TopicVoteState = (function () {
    function TopicVoteState() {
    }
    return TopicVoteState;
}());
exports.TopicVoteState = TopicVoteState;
/**
 * 发帖内容状态
 */
var PostTopicState = (function () {
    function PostTopicState() {
    }
    return PostTopicState;
}());
exports.PostTopicState = PostTopicState;
/**
 * 作者信息状态
 */
var AuthorMessageState = (function () {
    function AuthorMessageState() {
    }
    return AuthorMessageState;
}());
exports.AuthorMessageState = AuthorMessageState;
/**
 * 题目信息状态
 */
var TopicTitleState = (function () {
    function TopicTitleState() {
    }
    return TopicTitleState;
}());
exports.TopicTitleState = TopicTitleState;
/**
 * 文章内容
 */
var ContentState = (function () {
    function ContentState() {
    }
    return ContentState;
}());
exports.ContentState = ContentState;
/**
 * 点赞信息状态
 */
var TopicGoodState = (function () {
    function TopicGoodState() {
    }
    return TopicGoodState;
}());
exports.TopicGoodState = TopicGoodState;
/**
 * 回复者状态
 */
var ReplierState = (function () {
    function ReplierState() {
    }
    return ReplierState;
}());
exports.ReplierState = ReplierState;
var ListHeadState = (function () {
    function ListHeadState() {
    }
    return ListHeadState;
}());
exports.ListHeadState = ListHeadState;
var ListNoticeState = (function () {
    function ListNoticeState() {
    }
    return ListNoticeState;
}());
exports.ListNoticeState = ListNoticeState;
var ListTagState = (function () {
    function ListTagState() {
    }
    return ListTagState;
}());
exports.ListTagState = ListTagState;
var ListContentState = (function () {
    function ListContentState() {
    }
    return ListContentState;
}());
exports.ListContentState = ListContentState;
var TopicTitleAndContentState = (function () {
    /*  constructor(title, authorName, lastReply) {
          this.authorName = authorName;
          this.lastReply = lastReply;
          this.title = title;
      }*/
    function TopicTitleAndContentState(title, authorName) {
        this.authorName = authorName;
        this.title = title;
    }
    return TopicTitleAndContentState;
}());
exports.TopicTitleAndContentState = TopicTitleAndContentState;
var ListPagerState = (function () {
    function ListPagerState() {
    }
    return ListPagerState;
}());
exports.ListPagerState = ListPagerState;
var PagerState = (function () {
    function PagerState(page) {
        this.pageNumber = page;
    }
    return PagerState;
}());
exports.PagerState = PagerState;
//# sourceMappingURL=AppState.js.map

/***/ }),
/* 10 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ })
/******/ ]);