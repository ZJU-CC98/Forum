﻿import * as Prop from "./Props/AppProps"
import * as State from "./States/AppState"
import * as React from 'react';
import { TopicTitleAndContent } from "./Components/List"
import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom';

export async function getData() {
    let hottopics: State.TopicTitleAndContentState[] = [];
    var response = await fetch('http://api.cc98.org/Topic/Hot');
    var data: State.TopicTitleAndContentState[] = await response.json();
    for (var i = 0; i < 10; i++) {
        hottopics[i] = new State.TopicTitleAndContentState(data[i].title, data[i].authorName || '匿名');
    }

    var items = hottopics.map(convertHotTopic);

    return items ;
}
export function getPager(curPage) {
    let pages: State.PagerState[] = [];
    if (curPage == undefined || curPage == 1 || curPage == 2) {
        pages[0] = new State.PagerState(1);
        pages[1] = new State.PagerState(2);
        pages[2] = new State.PagerState(3);
        pages[3] = new State.PagerState(4);
        pages[4] = new State.PagerState(5);
    } else {
        pages[0] = new State.PagerState(curPage - 2);
        pages[1] = new State.PagerState(curPage - 1);
        pages[2] = new State.PagerState(curPage);
        pages[3] = new State.PagerState(curPage + 1);
        pages[4] = new State.PagerState(curPage + 2);
    }
    return pages;
}
export async function getBoardTopic(curPage) {
    var startPage = (curPage - 1) * 10 + 1;
    var endPage = curPage * 10;
    let boardtopics: State.TopicTitleAndContentState[] = [];
    var response = await fetch('http://api.cc98.org/Topic/Board/493', { headers: { Range: "bytes=" + startPage + "-" + endPage } });
    var data: State.TopicTitleAndContentState[] = await response.json();
    for (var i = 0; i < 10; i++) {
        boardtopics[i] = new State.TopicTitleAndContentState(data[i].title, data[i].authorName || '匿名');
    }
    return boardtopics;

}
export function convertHotTopic(item: State.TopicTitleAndContentState) {
    return <TopicTitleAndContent title={item.title} authorName={item.authorName} likeImgUrl="/images/like.jpg"
    unlikeImgUrl="/images/unlike.jpg"
    commentImgUrl= "/images/comment.jpg"/>;
}
export function pageNumber(pageNumber: State.PagerState) {
    var pageUrl = "/list/" + pageNumber.pageNumber;
    return <div> <Link className="pager" style={{
        width: "30px",
        height: "25px"}} to={pageUrl}>{pageNumber.pageNumber}</Link></div>;
}